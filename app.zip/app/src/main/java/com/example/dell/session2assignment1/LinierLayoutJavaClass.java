package com.example.dell.session2assignment1;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by dell on 10/23/2016.
 */
public class LinierLayoutJavaClass  extends AppCompatActivity{
@Override
protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linear_layout_example);
        }
        }
